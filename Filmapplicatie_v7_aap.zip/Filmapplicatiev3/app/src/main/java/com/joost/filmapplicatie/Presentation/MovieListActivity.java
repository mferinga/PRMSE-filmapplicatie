package com.joost.filmapplicatie.Presentation;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.joost.filmapplicatie.ApplicationLogic.DatasetListener;
import com.joost.filmapplicatie.ApplicationLogic.MovieListAdapter;
import com.joost.filmapplicatie.ApplicationLogic.MovieListListener;
import com.joost.filmapplicatie.DataStorage.AsyncDataRetrieve;
import com.joost.filmapplicatie.Domain.Movie;
import com.joost.filmapplicatie.Domain.MovieList;
import com.joost.filmapplicatie.R;

import java.util.ArrayList;
import java.util.List;


public class MovieListActivity extends AppCompatActivity implements MovieListListener, DatasetListener {

    protected List<MovieList> movieListList = new ArrayList<>();
    protected List<Movie> allMovies = new ArrayList<>();
    private RecyclerView recyclerView;
    private MovieListAdapter adapter;

    public static String clickedMovieList = "com.joost.shareameal.extra.CLICKED_MOVIELIST";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.movie_list_activity_main);

        new AsyncDataRetrieve(this).execute();

//        for (int i = 1; i <= 20; i++) {
//            List<Movie> tempMealList = new ArrayList<>();
//
//            for (int j = 1; j <= 20; j++) {
////                tempMealList.add(new Movie());
//                tempMealList.add(new Movie("Movie nummer: " + j, "4 april 2022", 5.5, "https://hips.hearstapps.com/nl.h-cdn.co/quote/images/quote/nieuws/record!-nog-nooit-zijn-er-zoveel-europese-unicorns-bijgekomen-in-een-half-jaar-216479/4227636-2-dut-NL/Record!-Nog-nooit-zijn-er-zoveel-Europese-Unicorns-bijgekomen-in-een-half-jaar.png"));
//                Log.i("MovieListActivity", "Test 230: " + j);
//            }
//
//            movieListList.add(new MovieList("Filmlijst nummer " + i, tempMealList));
////            movieListList.add(new MovieList("Filmlijst nummer " + i, new ArrayList<>()));
//
//        }

        for (MovieList ml : this.movieListList) {
            Log.i("MovieListActivity", "Test 200: " + ml.getTitle());
        }

        recyclerView = findViewById(R.id.movie_list_activity_recyclerview);
        Log.i("MovieListActivity", "Test 201: Recyclerview gekoppeld");

        adapter = new MovieListAdapter(this, movieListList);
        Log.i("MovieListActivity", "Test 202: Adapter gemaakt");

        recyclerView.setAdapter(adapter);
        Log.i("MovieListActivity", "Test 203: Adapter gekoppeld aan Recyclerview");

        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));
        Log.i("MovieListActivity", "Test 204: recyclerview layout gezet");


        Bundle extras = getIntent().getExtras();
        Log.i("Create Movie info","Test 1200: " + extras);
        checkNewListCreated(extras);
    }

    public void checkNewListCreated(Bundle extras){
        if(extras != null){
            String movieListTitle = extras.getString("movieListTitle");
            String movieTitle = extras.getString("movieTitles");

            List<Movie> movies = new ArrayList<>();
            Movie movie = new Movie(movieTitle);
            movies.add(movie);

            MovieList movieList = new MovieList(movieListTitle, movies);

            movieListList.add(movieList);
            adapter.notifyItemInserted(movieListList.size() - 1);
        }
    }

    @Override
    public void showMoviesPage(MovieList movieList) {
        Log.i("MovieListActivity", "Test 210: MovieList clicked, showing movies page!");

        Intent intent = new Intent(this, MoviesActivity.class);
        Log.i("MovieListActivity", "Test 211: Intent gemaakt");

        // let op Serializable
        intent.putExtra(clickedMovieList, movieList);
        Log.i("MovieListActivity", "Test 212: Aangeklikte movielist in intent gestopt");
        startActivity(intent);

    }

    @Override
    public void addMovie(Movie movie) {
        this.allMovies.add(movie);
        Log.i("MovieListActivity", "Test 1000: nieuwe film -> " + movie.getTitle());

    }

    @Override
    public void datasetUpdated() {
        Log.i("MovieListActivity", "Test 1010: aantal films -> " + this.allMovies.size());
        this.movieListList.add(new MovieList("All movies", this.allMovies));
        this.adapter.notifyDataSetChanged();
        Log.d("MovieListActivity", "Dataset updated");
    }

    public void createNewMovieList(View view) {
        Intent intent = new Intent(this, CreateMovieList.class);
        startActivity(intent);
    }
}
