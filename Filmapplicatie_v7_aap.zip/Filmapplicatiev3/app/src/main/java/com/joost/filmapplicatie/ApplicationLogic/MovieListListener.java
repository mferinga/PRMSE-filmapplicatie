package com.joost.filmapplicatie.ApplicationLogic;

import com.joost.filmapplicatie.Domain.MovieList;

public interface MovieListListener {

    public void showMoviesPage(MovieList movieList);
}
