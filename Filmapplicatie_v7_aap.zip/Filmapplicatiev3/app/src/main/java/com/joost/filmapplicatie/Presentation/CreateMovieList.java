package com.joost.filmapplicatie.Presentation;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.joost.filmapplicatie.R;

import java.util.ArrayList;

public class CreateMovieList extends AppCompatActivity {

    private String[] titles;
    private Spinner spinner;
    private EditText movieListTitleInput;
    private String movieListTitle;
    private String movieTitle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.create_movie_list);
        titles = new String[]{"Movie1", "Movie2", "Movie3", "Movie4", "Movie5"};
        setTitlesInSpinner();
    }

    public void setTitlesInSpinner(){
        spinner = findViewById(R.id.spinner);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, titles);
        spinner.setAdapter(adapter);
    }

    public void getData(){
        movieListTitleInput = findViewById(R.id.movieListTitleInput);
        movieListTitle = movieListTitleInput.getText().toString().trim();

        movieTitle = spinner.getSelectedItem().toString();
    }

    public void submitMovie(View view) {
        Intent intent = new Intent(this, MovieListActivity.class);
        getData();
        intent.putExtra("movieListTitle", movieListTitle);
        intent.putExtra("movieTitles", movieTitle);
        startActivity(intent);
    }
}
