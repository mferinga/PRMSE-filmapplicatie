package com.joost.filmapplicatie.Presentation;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.joost.filmapplicatie.ApplicationLogic.MovieListAdapter;
import com.joost.filmapplicatie.ApplicationLogic.MovieListener;
import com.joost.filmapplicatie.ApplicationLogic.MoviesAdapter;
import com.joost.filmapplicatie.Domain.Movie;
import com.joost.filmapplicatie.Domain.MovieList;
import com.joost.filmapplicatie.R;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MoviesActivity extends AppCompatActivity implements MovieListener {

    protected MovieList movieList;
    private RecyclerView recyclerView;
    private MoviesAdapter adapter;

    public static String clickedMovie = "com.joost.shareameal.extra.CLICKED_MOVIE";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i("MovieListActivity", "Test 599: MoviesActivity Start");
        setContentView(R.layout.movies_activity_main);


        Log.i("MovieListActivity", "Test 500: MoviesActivity laden...");

        this.movieList = (MovieList) getIntent().getSerializableExtra(MovieListActivity.clickedMovieList);

        recyclerView = findViewById(R.id.movies_activity_recyclerview);
        Log.i("MovieListActivity", "Test 501: Recyclerview gekoppeld");

        adapter = new MoviesAdapter(this, movieList);
        Log.i("MovieListActivity", "Test 502: Adapter gemaakt");

        recyclerView.setAdapter(adapter);
        Log.i("MovieListActivity", "Test 503: Adapter gekoppeld aan Recyclerview");

        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));
        Log.i("MovieListActivity", "Test 504: recyclerview layout gezet");

    }

    @Override
    public void showMoviesDetailPage(Movie movie) {
        Log.i("MovieListActivity", "Test 510: recyclerview layout gezet");

        Intent intent = new Intent(this, MovieDetailActivity.class);
        Log.i("MovieListActivity", "Test 511: Intent gemaakt");

        // let op Serializable
        intent.putExtra(clickedMovie, movie);
        Log.i("MovieListActivity", "Test 512: Aangeklikte movie in intent gestopt");
        startActivity(intent);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.movie_page_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        switch(item.getItemId()){

            case R.id.sort_title_az:
                Collections.sort(movieList.getMovieList(), Movie.MovieTitleAZComparator);
                Toast.makeText(this, "Sort data on title", Toast.LENGTH_SHORT).show();
                adapter.notifyDataSetChanged();
                break;

            case R.id.sort_title_za:
                Collections.sort(movieList.getMovieList(), Movie.MovieTitleZAComparator);
                Toast.makeText(this, "Sort data on title", Toast.LENGTH_SHORT).show();
                adapter.notifyDataSetChanged();
                break;

            case R.id.sort_date_new_old:
                Collections.sort(movieList.getMovieList(), Movie.MovieDateNewToOldComparator);
                Toast.makeText(this, "Sort data on date", Toast.LENGTH_SHORT).show();
                adapter.notifyDataSetChanged();
                break;

            case R.id.sort_date_old_new:
                Collections.sort(movieList.getMovieList(), Movie.MovieDateOldToNewComparator);
                Toast.makeText(this, "Sort data on date", Toast.LENGTH_SHORT).show();
                adapter.notifyDataSetChanged();
                break;

            case R.id.sort_rating_high_low:
                Collections.sort(movieList.getMovieList(), Movie.MovieRatingHighToLowComparator);
                Toast.makeText(this, "Sort data on rating", Toast.LENGTH_SHORT).show();
                adapter.notifyDataSetChanged();
                break;

            case R.id.sort_rating_low_high:
                Collections.sort(movieList.getMovieList(), Movie.MovieRatingLowToHighComparator);
                Toast.makeText(this, "Sort data on rating", Toast.LENGTH_SHORT).show();
                adapter.notifyDataSetChanged();
                break;

        }


        return super.onOptionsItemSelected(item);
    }
}
