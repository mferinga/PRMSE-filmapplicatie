package com.joost.filmapplicatie.ApplicationLogic;

import com.joost.filmapplicatie.Domain.Movie;

public interface DatasetListener {

    public void addMovie(Movie movie);

    public void datasetUpdated();

}
