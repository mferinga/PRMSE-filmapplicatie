package com.joost.filmapplicatie.Presentation;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.joost.filmapplicatie.Domain.Movie;
import com.joost.filmapplicatie.R;
import com.squareup.picasso.Picasso;

public class MovieDetailActivity extends AppCompatActivity {

    private TextView movieTitle;
    private TextView movieDate;
    private ImageView movieImage;
    private RatingBar movieRating;
    private TextView movieDescription;

    private Movie clickedMovie;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.movie_detail_activity_main);

        this.clickedMovie = (Movie) getIntent().getSerializableExtra(MoviesActivity.clickedMovie);

        movieTitle = findViewById(R.id.movie_detail_title);
        movieDate = findViewById(R.id.movie_detail_date);
        movieImage= findViewById(R.id.movie_detail_image);
        movieRating = findViewById(R.id.movie_detail_rating);
        movieDescription = findViewById(R.id.movie_detail_description);

        movieTitle.setText(clickedMovie.getTitle());
        movieDate.setText(clickedMovie.getDate());
        movieRating.setRating((float) clickedMovie.getRating() / 2);
        movieDescription.setText(clickedMovie.getDescription());

        // Image async ophalen met Picasso en deze aan de ImageView toekennen
        String url = this.clickedMovie.getImageLink();
        Picasso.get().load(url).into(movieImage);

    }

}
