package com.joost.filmapplicatie.ApplicationLogic;

import com.joost.filmapplicatie.Domain.Movie;

public interface MovieListener {

    public void showMoviesDetailPage(Movie movie);

}
