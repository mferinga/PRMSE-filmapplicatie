package com.joost.filmapplicatie.DataStorage;

import android.net.Uri;
import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class NetworkUtils {
    private static final String LOG_TAG = NetworkUtils.class.getSimpleName();
    private static final String MOVIE_BASE_URL =  "https://api.themoviedb.org/3/movie/popular?api_key=12370ac49bb17ff087470862c5fde9ce&language=en-US";

    static String getMovieList(){
        HttpURLConnection urlConnection = null;
        BufferedReader reader = null;
        String movieJSONString = null;

        try{

            Uri builtURI = Uri.parse(MOVIE_BASE_URL).buildUpon().build();
            URL requestURL = new URL(builtURI.toString());

            //Getting connection with the API
            urlConnection = (HttpURLConnection) requestURL.openConnection();
            urlConnection.setRequestMethod("GET");
            urlConnection.connect();

            //Creating a reader and a writing for scanning through the API code
            InputStream inputStream = urlConnection.getInputStream();
            reader = new BufferedReader(new InputStreamReader(inputStream));
            StringBuilder builder = new StringBuilder();

            //writing the lines from the API to the StringBuilder
            String line;
            while ((line = reader.readLine()) != null){
                builder.append(line);
                builder.append("\n");
            }

            //checks if the builder isn't empty else return null
            if(builder.length() == 0){
                return null;
            }

            //storing the builder.toString() into the mealJSONString attribute
            movieJSONString = builder.toString();

        } catch (IOException e){
            e.printStackTrace();
        } finally {
            if (urlConnection != null){
                urlConnection.disconnect();
            }
            if (reader != null){
                try {
                    reader.close();
                } catch (IOException e){
                    e.printStackTrace();
                }
            }
        }

        //returns the mealJSONString attribute which contains all the information from the API

        Log.d("NetworkUtils", "Test 900: API called!");
        Log.d(LOG_TAG, movieJSONString);
        return movieJSONString;
    }
}