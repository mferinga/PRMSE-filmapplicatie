package com.joost.filmapplicatie.DataStorage;


import android.os.AsyncTask;
import android.util.Log;


import com.joost.filmapplicatie.ApplicationLogic.DatasetListener;
import com.joost.filmapplicatie.Domain.Movie;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class AsyncDataRetrieve extends AsyncTask<Void, Void, String> {

    private DatasetListener listener;

    public AsyncDataRetrieve(DatasetListener listener) {
        this.listener = listener;
    }

    @Override
    protected String doInBackground(Void... voids) {

        return NetworkUtils.getMovieList();
    }

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);

        try {

            Log.d("AsyncDataRetrieve", "Test 800: Data");
            JSONObject jsonObject = new JSONObject(s);
            Log.d("AsyncDataRetrieve", "Test 801: JSONObject created");

            JSONArray itemsArray = jsonObject.getJSONArray("results");



//            Log.d("AsyncDataRetrieve", "Test 805:" + itemsArray);

            Log.d("AsyncDataRetrieve", "Test 806: Data");



            int i = 0;

            String movieName = null;
            String movieReleaseDate = null;
            String movieImageLink = null;
            double movieRating = 0;
            String movieDescription = null;



//            boolean mealIsVega = false;
//            boolean mealIsVegan = false;
//            boolean mealisToTakeHome = false;
//            int mealMaxAmountOfParticipants = 0;
//            JSONArray mealAllergenesJSONArray = null;
//            JSONObject cookJSONObject = null;
//            List<String> mealAllergenesList = null;


            while (i < itemsArray.length()) {

                Log.d("AsyncDataRetrieve", "Test 802: i = " + i);

                JSONObject movie = itemsArray.getJSONObject(i);

                try {

                    movieName = movie.getString("title");
                    movieReleaseDate = movie.getString("release_date");
                    movieImageLink = "https://image.tmdb.org/t/p/w500/" + movie.getString("backdrop_path");
                    movieRating = movie.getDouble("vote_average");
                    movieDescription = movie.getString("overview");

//                    movieImageLink = "https://hips.hearstapps.com/nl.h-cdn.co/quote/images/quote/nieuws/record!-nog-nooit-zijn-er-zoveel-europese-unicorns-bijgekomen-in-een-half-jaar-216479/4227636-2-dut-NL/Record!-Nog-nooit-zijn-er-zoveel-Europese-Unicorns-bijgekomen-in-een-half-jaar.png";


                    Log.d("AsyncDataRetrieve", "Test 803: movieName = "  + movieName);
                    Log.d("AsyncDataRetrieve", "Test 804: movieReleaseDate = "  + movieReleaseDate);
                    Log.d("AsyncDataRetrieve", "Test 805: movieImageLink = "  + movieImageLink);
                    Log.d("AsyncDataRetrieve", "Test 806: movieRating = "  + movieRating);
                    Log.d("AsyncDataRetrieve", "Test 807: movieDescription = "  + movieDescription);
                    Log.d("AsyncDataRetrieve", "Test 808: ------------");

                    listener.addMovie(new Movie(movieName, movieReleaseDate, movieImageLink, movieRating, movieDescription));

//                    listener.addMeal(new Meal(mealName, mealDescription, mealDate, mealPrice, mealImageURL, mealIsVega, mealIsVegan, mealisToTakeHome, mealMaxAmountOfParticipants, mealAllergenesList, cookOfMeal));

                } catch (Exception e) {
                    e.printStackTrace();
                }

                i++;
            }

            listener.datasetUpdated();


        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

}
